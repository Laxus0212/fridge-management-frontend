export const environment = {
  production: false,
  BASE_URL: 'http://localhost:3000',
};
