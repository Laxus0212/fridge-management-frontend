export const environment = {
  production: true,
  BASE_URL: 'https://varadinas.synology.me:3000/api',
};
